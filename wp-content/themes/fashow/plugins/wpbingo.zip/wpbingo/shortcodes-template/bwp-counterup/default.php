<div class="bwp-counterup">
	<?php if( $number) : ?>
		<div class="number-counterup"><?php echo esc_html( $number ); ?></div>
	<?php endif; ?>

	<?php if(isset($title1) && $title1) : ?>
		<h4 class="title-counterup"><?php echo esc_html( $title1 ); ?></h4>
	<?php endif; ?>
</div><!-- .bwp-counterup -->
